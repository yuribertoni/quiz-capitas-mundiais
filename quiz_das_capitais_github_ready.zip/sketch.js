var estado = "menu"
var pontosfacil = 0
var pontosmedio = 0
var pontosdificil = 0

var respondeuFacil1 = false, respondeuFacil2 = false, respondeuFacil3 = false;
var respondeuFacil4 = false, respondeuFacil5 = false, respondeuFacil6 = false;
var respondeuFacil7 = false, respondeuFacil8 = false, respondeuFacil9 = false;

var respondeuMedio1 = false, respondeuMedio2 = false, respondeuMedio3 = false;
var respondeuMedio4 = false, respondeuMedio5 = false, respondeuMedio6 = false;
var respondeuMedio7 = false, respondeuMedio8 = false, respondeuMedio9 = false;


var respondeuDificil1 = false, respondeuDificil2 = false, respondeuDificil3 = false;
var respondeuDificil4 = false, respondeuDificil5 = false, respondeuDificil6 = false;
var respondeuDificil7 = false, respondeuDificil8 = false, respondeuDificil9 = false;



// BOTÕES DAS RESPOSTAS
var b11 = false, b12 = false, b13 = false, b14 = false;
var b21 = false, b22 = false, b23 = false, b24 = false;
var b31 = false, b32 = false, b33 = false, b34 = false;


// Função para limpar botões
function limparRespostas() {
 b11 = b12 = b13 = b14 = false;
 b21 = b22 = b23 = b24 = false;
 b31 = b32 = b33 = b34 = false;
}

// Função para limpar flags de controle

function setup() {
  createCanvas(600, 600);
  textStyle(ITALIC)
}  

function preload(){

albania = loadImage('albania.png')
alemanha = loadImage('alemanha.png')
australia = loadImage('australia.png')
brasil = loadImage('brasil.png')
canada = loadImage('canada.png')
catar = loadImage('catar.png')
china = loadImage('china.png')
coreiadosul = loadImage('coreiadosul.png')
cuba = loadImage('cuba.png')
dinamarca = loadImage('dinamarca.png')
escocia = loadImage('escocia.png')
espanha = loadImage('espanha.png')
eua = loadImage('eua.png')
frança= loadImage('frança.png')
grecia= loadImage('grecia.png')
irlanda = loadImage('irlanda.png')
israel = loadImage('israel.png')
italia = loadImage('itália.png')
japão = loadImage('japão.png')
macedoniadonorte = loadImage('macedoniadonorte.png')
libano = loadImage('libano.png')
mexico = loadImage('méxico.png')
nepal = loadImage('nepal.png')
nicaragua = loadImage('nicaragua.png')
reinounido = loadImage('reinounido.png')
suiça = loadImage('suiça.png')
vietna = loadImage('vietna.png')
estrela = loadImage('estrela.jpg')
globo = loadImage('globo.jpg')
}
// preload das bandeiras dos países

function draw() {
  background("white");
  
  if(estado == "menu"){
    telaMenu()
  }
  if(estado == "jogar"){
    telaJogar()
  }
  if(estado == "creditos"){
    telaCreditos()
  }
  if(estado == "controles"){
    telaControles()
  }
  if( estado == "nivel facil"){
    telaNivelfacil()
  }
  if(estado == "nivel medio"){
    telaNivelmedio()
  }
  if(estado == "nivel dificil"){
    telaNiveldificil()
  }
  if(estado =="facil2"){
    telaFacil2()
  }
  if(estado == "facil3"){
    telaFacil3()
  }
  if(estado == "medio2"){
    telaMedio2()
  }
  if(estado == "medio3"){
    telaMedio3()
  }
  if(estado == "dificil2"){
    telaDificil2()
  }
  if(estado == "dificil3"){
    telaDificil3()
  }

} //mudança de telas

function mousePressed(){
  
  if(estado == "menu"){
    
  if (mouseX >20 && mouseX < 120 && mouseY > 50 && mouseY < 80 ){
    estado = "jogar"
    return
  }
    
  if( mouseX > 20 && mouseX < 120 && mouseY > 100 && mouseY < 130){
    estado = "creditos"
  }
  if(mouseX > 20 && mouseX < 120 && mouseY > 150 && mouseY < 180){
    estado = "controles"
  }
    
} // botões relacionados a tela menu

  if(estado == "jogar"){
    
  if (mouseX >20 && mouseX < 120 && mouseY > 50 && mouseY < 80 ){
    estado = "nivel facil"
  }
   if(mouseX > 20 && mouseX < 120 && mouseY > 100 && mouseY < 130){
    estado = "nivel medio"
  }
   if(mouseX > 20 && mouseX < 120 && mouseY > 150 && mouseY < 180){
    estado = "nivel dificil"
  }
   if(mouseX > 20 && mouseX < 120 && mouseY > 200 && mouseY < 230){
    estado = "menu"
  }   
    
} // botões relacionados a tela jogar
    
  if ((estado == "creditos" || estado == "controles") &&
    mouseX > 20 && mouseX < 140 && mouseY > 400 && mouseY < 430) {
  estado = "menu";
  
} // botões tela créditos e tela controles
    
    if(estado == "nivel facil"){
      if(mouseX >450 && mouseX < 560 && mouseY > 20 && mouseY < 50){
        limparRespostas();
        estado = "facil2"
        return;
      }
      if(!respondeuFacil1 && mouseX > 250 && mouseX < 370 && mouseY > 50 && mouseY < 75){
        pontosfacil += 1
        respondeuFacil1 = true
        return
      }
        if(!respondeuFacil2 && mouseX > 250 && mouseX < 370 && mouseY > 280 && mouseY < 295){
        pontosfacil += 1
        respondeuFacil2 = true
        b22 = true
        return
      }
        if(!respondeuFacil3 && mouseX > 250 && mouseX < 370 && mouseY > 540 && mouseY < 555){
        pontosfacil += 1
        b34 = true
        respondeuFacil3 = true
        return
}
        
    }
    if(estado == "facil2"){
      if(mouseX >450 && mouseX < 560 && mouseY > 20 && mouseY < 50){
        limparRespostas();
        estado = "facil3"
    return;
    
      }
      if(!respondeuFacil4 && mouseX > 250 && mouseX < 370 && mouseY > 110 && mouseY < 125){
        pontosfacil += 1
        b13 = true
        respondeuFacil4 = true
        return
    }
      if (!respondeuFacil5 &&mouseX > 250 && mouseX < 370 && mouseY > 340 && mouseY < 355) {
        pontosfacil += 1
        b24 = true
        respondeuFacil5 = true
        return
  }
      if (!respondeuFacil6 && mouseX > 250 && mouseX < 370 && mouseY > 450 && mouseY < 465) {
        pontosfacil += 1
        b31 = true
        respondeuFacil6 = true
        return
  }
    }
      
    if(estado == "facil3"){
      if(mouseX >450 && mouseX < 560 && mouseY > 80 && mouseY < 110){
        limparRespostas();
        estado = "jogar"
        return;
    }
        if (!respondeuFacil7 && mouseX > 250 && mouseX < 370 && mouseY > 110 && mouseY < 125) {
        pontosfacil += 1
        b13 = true
        respondeuFacil7 = true
        return
    }
        if (!respondeuFacil8 && mouseX > 250 && mouseX < 370 && mouseY > 340 && mouseY < 355) {
        pontosfacil += 1
        b24 = true
        respondeuFacil8 = true
        return
    }
        if (!respondeuFacil9 &&mouseX > 250 && mouseX < 370 && mouseY > 450 && mouseY < 465) {
        pontosfacil += 1
        b31 = true
        respondeuFacil9 = true
        return
    }
        
  }
    if(estado == "nivel medio"){
      if(mouseX >450 && mouseX < 560 && mouseY > 20 && mouseY < 50){
        limparRespostas();
        estado = "medio2"
    return;
      
    }
        if (!respondeuMedio1 && mouseX > 250 && mouseX < 370 && mouseY > 50 && mouseY < 65) {
        pontosmedio += 1
        b11 = true
        respondeuMedio1 = true
        return
    }
        if (!respondeuMedio2 &&mouseX > 250 && mouseX < 370 && mouseY > 340 && mouseY < 355) {
        pontosmedio += 1
        b24 = true
        respondeuMedio2 = true
        return
    }
        if (!respondeuMedio3 &&mouseX > 250 && mouseX < 370 && mouseY > 450 && mouseY < 465) {
        pontosmedio += 1
        b31 = true
        respondeuMedio3 = true
        return
    }
      
    }
    if(estado == "medio2"){
      if(mouseX >450 && mouseX < 560 && mouseY > 20 && mouseY < 50){
        limparRespostas();
        estado = "medio3"
        return;
        
    }
        if (!respondeuMedio4 && mouseX > 250 && mouseX < 370 && mouseY > 80 && mouseY < 95) {
        pontosmedio += 1
        b12 = true
        respondeuMedio4 = true
        return
    }
        if (!respondeuMedio5 && mouseX > 250 && mouseX < 370 && mouseY > 340 && mouseY < 355) {
        pontosmedio += 1
        b24 = true
        respondeuMedio5 = true
        return
    }
        if (!respondeuMedio6 && mouseX > 250 && mouseX < 370 && mouseY > 510 && mouseY < 525) {
        pontosmedio += 1
        b33 = true
        respondeuMedio6 = true
        return
        }
    }
   if(estado == "medio3"){
      if(mouseX >450 && mouseX < 560 && mouseY > 80 && mouseY < 110){
        limparRespostas();
        estado = "jogar"
    }
       if (!respondeuMedio7 && mouseX > 250 && mouseX < 370 && mouseY > 110 && mouseY < 125) {
        pontosmedio += 1
        b13 = true
        respondeuMedio7 = true
        return
    }
      if (!respondeuMedio8 && mouseX > 250 && mouseX < 370 && mouseY > 250 && mouseY < 265) {
        pontosmedio += 1
        b21 = true
        respondeuMedio8 = true
        return
    }
        if (!respondeuMedio9 && mouseX > 250 && mouseX < 370 && mouseY > 540 && mouseY < 555) {
        pontosmedio += 1
        b34 = true
        respondeuMedio9 = true
        return
    }
      
    }
        
     if(estado == "nivel dificil"){
      if(mouseX >450 && mouseX < 560 && mouseY > 20 && mouseY < 50){
        limparRespostas();
        estado = "dificil2"
        return
      }
        if (!respondeuDificil1 && mouseX > 250 && mouseX < 370 && mouseY > 80 && mouseY < 95) {
        pontosdificil += 1
        b12 = true
        respondeuDificil1 = true
        return
    }
        if (!respondeuDificil2 && mouseX > 250 && mouseX < 370 && mouseY > 340 && mouseY < 355) {
        pontosdificil += 1
        b34 = true
        respondeuDificil2 = true
        return
    }
       if (!respondeuDificil3 && mouseX > 250 && mouseX < 370 && mouseY > 450 && mouseY < 465) {
        pontosdificil += 1
        b31 = true
        respondeuDificil3 = true
        return
    }
  }
    if(estado == "dificil2"){
      if(mouseX >450 && mouseX < 560 && mouseY > 20 && mouseY < 50){
        limparRespostas();
        estado = "dificil3"
        return;
      }
        if (!respondeuDificil4 && mouseX > 250 && mouseX < 370 && mouseY > 80 && mouseY < 95) {
        pontosdificil += 1
        b12 = true
        respondeuDificil4 = true
        return
    }
       if (!respondeuDificil5 && mouseX > 250 && mouseX < 370 && mouseY > 250 && mouseY < 265) {
        pontosdificil += 1
        b21 = true
        respondeuDificil5 = true
       return
    }
       if (!respondeuDificil6 && mouseX > 250 && mouseX < 370 && mouseY > 540 && mouseY < 555) {
        pontosdificil += 1
       b34 = true
        respondeuDificil6 = true
       return
    }
  } 
      
    if(estado == "dificil3"){
      if(mouseX >450 && mouseX < 560 && mouseY > 80 && mouseY < 110){
        estado = "jogar"
      }
      if (!respondeuDificil7 && mouseX > 250 && mouseX < 370 && mouseY > 80 && mouseY < 95) {
      pontosdificil += 1
      b12 = true
      respondeuDificil7 = true
      return
  }
      if (!respondeuDificil8 && mouseX > 250 && mouseX < 370 && mouseY > 250 && mouseY < 265) {
      pontosdificil += 1
      b21 = true
      respondeuDificil8 = true
        return
      if (!respondeuDificil9 && mouseX > 250 && mouseX < 370 && mouseY > 480 && mouseY < 495) {
      pontosdificil += 1
      b32 = true
      respondeuDificil9 = true
      return
  }
    
    }
      }
    // botões mudança de tela das fases
    
  
    if(mouseX > 250 && mouseX < 370 && mouseY > 50 && mouseY < 65){
      b11 = !b11
    }
    if(mouseX > 250 && mouseX < 370 && mouseY > 80 && mouseY < 95){
      b12 = !b12
    }
    if (mouseX > 250 && mouseX < 370 && mouseY > 110 && mouseY < 125){
      b13 = !b13
    }
    if (mouseX > 250 && mouseX < 370 && mouseY > 140 && mouseY < 155){
      b14 = !b14
    } // botões 1
       
    if(mouseX > 250 && mouseX < 370 && mouseY > 250 && mouseY < 265){
      b21 = !b21
    }
    if(mouseX > 250 && mouseX < 370 && mouseY > 280 && mouseY < 295){
      b22 = !b22
    }
    if (mouseX > 250 && mouseX < 370 && mouseY > 310 && mouseY < 325){
      b23 = !b23
    }
    if (mouseX > 250 && mouseX < 370 && mouseY > 340 && mouseY < 355){
      b24 = !b24
    } // botoões 2
       
    if(mouseX > 250 && mouseX < 370 && mouseY > 450 && mouseY < 465){
      b31 = !b31
    }
    if(mouseX > 250 && mouseX < 370 && mouseY > 480 && mouseY < 495){
      b32 = !b32
    }
    if (mouseX > 250 && mouseX < 370 && mouseY > 510 && mouseY < 525){
      b33 = !b33
    }
    if (mouseX > 250 && mouseX < 370 && mouseY > 540 && mouseY < 555){
      b34 = !b34
    }          
}// função para detectar o clique do botão

  function telaMenu(){
  image(globo,100,60,500,500)
  textAlign(CENTER, CENTER)
  textSize(20)
  
  fill("blue")
  rect(20, 50, 110, 30, 10)  // botão jogar
  fill("white")
  text("Jogar", 75, 70)

  fill('blue')
  rect(20, 100, 110, 30, 10)  // botão créditos
  fill("white")
  text("Créditos", 75, 120)
  
  fill("blue")
  rect(20, 150, 110, 30, 10) // botão regras
  fill("white")
  text("Controles", 75, 170)
  
  fill("black")
  text("QUIZ DAS CAPITAIS MUNDIAIS", 350,  70)
 
  } // tela menu
  
  function telaJogar(){
  image(estrela,140,55,20,20)
    
  image(estrela,140,105,20,20)
  image(estrela,165,105,20,20)
  image(estrela,190,105,20,20)
    
  image(estrela,140,155,20,20)
  image(estrela,165,155,20,20)
  image(estrela,190,155,20,20)
  image(estrela,215,155,20,20)
  image(estrela,240,155,20,20)

  image(globo,300,20,300,300)

  textAlign(CENTER, CENTER)
  textSize(20)

  fill("blue")
  rect(20, 50, 110, 30, 10)  // botão nível fácil
  fill("white")
  text("Nível fácil", 75, 70)  
  
  fill('blue')
  rect(20, 100, 110, 30, 10)  // botao nivel medio
  fill("white")
  text("Nível médio", 75, 120)
    
  fill("blue")
  rect(20, 150, 110, 30, 10) // botão nível difícil
  fill("white")
  text("Nível difícil", 75, 170)
    
  fill("blue")
  rect(20, 200, 110, 30, 10) // botão menu
  fill("white")
  text("Menu", 75, 220)
    
  }
  
  function telaCreditos(){
    textAlign(CENTER, CENTER)
    fill("black")
    textSize(20)
    text("Aluno: Yuri Bertoni Dias Nogueira", 200, 50)
    
    textAlign(CENTER, CENTER)
    text("Email: yuri.bertoni.710@ufrn.edu.br", 209, 100)
    
    fill("blue")
    rect(20, 400, 110, 30, 10);
    fill("white");
    text("Menu", 75, 420); // botão menu - tela créditos
    
  }
  
  function telaControles(){
    textAlign(CENTER, CENTER)
    fill("black")
    textSize(20)
    text("=> O jogo consiste em um quiz sobre as capitais dos países", 290, 100)
    text("=> O jogo possui 3 níveis de dificuldade", 200, 150)
    text("=> Nível fácil -- Nível médio --  Nível difícil", 210,200)
    text("=> Tente alcançar o máximo de pontos em cada fase",260,250)
   
    fill("blue");
    rect(20, 400, 110, 30, 10);
    fill("white");
    text("Menu", 75, 420); // botão menu - tela controles
}

  function telaNivelfacil(){
  image(brasil, 50, 50, 100, 100)
  image(canada, 50,250, 100, 100)
  image(japão, 50, 450, 100, 100)
    
  fill("black")
  text("Brasil",100,170)
  text("Canadá",100,370)
  text("Japão",100,570)
  
  text("Nível fácil",310, 30)
  
  fill("blue")
  rect(450, 20, 110, 30, 10)
  fill("white")
  text("Próximo", 500, 35) // botão próxima tela
    
  for (var i = 0; i < 4; i++) {
    fill("blue");
    rect(250, 50 + i * 30, 120, 15, 10);
  }
  
  if (b11) {
    fill("green"); // certos
  rect(250, 50 ,120, 15, 10) // certa

  }else if( b12 || b13 || b14){
    fill("red")
  rect(250, 80, 120, 15, 10)
  rect(250, 110, 120, 15, 10)
  rect(250, 140, 120, 15, 10)
    
  } else {
    fill("blue"); // Normal
  }
// botões das alternativas 1
  textSize(16)
  fill("white")
  text("Brasilía", 310, 60)

    
  textSize(16)
  fill("white")
  text("Rio de Janeiro", 310, 90)
    
  textSize(16)
  fill("white")
  text("Salvador", 310, 120)
    
  textSize(16)
  fill("white")
  text("São Paulo", 310, 150)
 // texto alternativas 1
    
    
  for (var i = 0; i < 4; i++) {
    fill("blue");
    rect(250,250 + i * 30, 120, 15, 10);
  }
  // botões alternativas 2

  if (b22) {
    fill("green"); // certos
  rect(250, 280, 120, 15, 10) // certa
  }else if( b21 || b23 || b24){
    fill("red")
  rect(250, 310, 120, 15, 10)
  rect(250, 340, 120, 15, 10)
  rect(250, 250, 120, 15, 10)
  }  

  textSize(16)
  fill("white")
  text("Toronto", 310, 260)

    
  textSize(16)
  fill("white")
  text("Ottawwa", 310, 290)
    
  textSize(16)
  fill("white")
  text("Montreal", 310, 320)
    
  textSize(16)
  fill("white")
  text("Quebec", 310, 350)
 // texto alternativas 2
    
  for (var i = 0; i < 4; i++) {
    fill("blue");
    rect(250, 450 + i * 30, 120, 15, 10);
  }
  // botões alternativas 3

  if (b34) {
    fill("green"); // certos
  rect(250, 540, 120, 15, 10) // certa

  }else if( b31 || b33 || b32){
    fill("red")
  rect(250, 450, 120, 15, 10)
  rect(250, 480, 120, 15, 10)
  rect(250, 510, 120, 15, 10)
  }  
    
  textSize(16)
  fill("white")
  text("Hiroshima", 310, 460)

  textSize(16)
  fill("white")
  text("Pequim", 310, 490)
    
  textSize(16)
  fill("white")
  text("Quioto", 310, 520)
    
  textSize(16)
  fill("white")
  text("Tóquio", 310, 550)
 // texto alternativas 3
    

  } // primeira tela nivel facil
  
  function telaFacil2(){
      
  image(alemanha, 50, 50, 100, 100)
  image(espanha, 50,250, 100, 100)
  image(coreiadosul, 50, 450, 100, 100)

  fill("black")
  text("Alemanha",100,170)
  text("Espanha",100,370)
  text("Coréia do Sul",100,570)
  text("Nível fácil",310, 30)

  fill("blue")
  rect(450, 20, 110, 30, 10)
  fill("white")
  text("Próximo", 500, 35) // botão próxima tela

  for (var i = 0; i < 4; i++) {
    fill("blue");
    rect(250, 50 + i * 30, 120, 15, 10);
  }
  
  if (b13) {
    fill("green"); // certos
  rect(250, 110, 120, 15, 10) // certa

  }else if( b11 || b12 || b14){
    fill("red")
  rect(250, 50, 120, 15, 10) 
  rect(250, 80, 120, 15, 10) 
  rect(250, 140, 120, 15, 10)
  } else {
    fill("blue"); // Normal
  }
    
  textSize(16)
  fill("white")
  text("Frankfurt", 310, 60)
    
  textSize(16)
  fill("white")
  text("Hamburgo", 310, 90)
    
  textSize(16)
  fill("white")
  text("Berlim", 310, 120)
    
  textSize(16)
  fill("white")
  text("Munique", 310, 150)
    
 // texto alternativas 1
    
  for (var i = 0; i < 4; i++) {
    fill("blue");
    rect(250, 250 + i * 30, 120, 15, 10);
  }
    
  if (b24) {
    fill("green"); // certos
  rect(250, 340, 120, 15, 10) // certa

  }else if( b21 || b22 || b23){
    fill("red")
  rect(250, 250, 120, 15, 10)
  rect(250, 280, 120, 15, 10) 
  rect(250, 310, 120, 15, 10)
  } else {
    fill("blue"); // Normal
  }
  
  textSize(16)
  fill("white")
  text("Valência", 310, 260)

    
  textSize(16)
  fill("white")
  text("Lisboa", 310, 290)
    
  textSize(16)
  fill("white")
  text("Barcelona", 310, 320)
    
  textSize(16)
  fill("white")
  text("Madrid", 310, 350)
 // texto alternativas 2
    
  for (var i = 0; i < 4; i++) {
    fill("blue");
    rect(250, 450 + i * 30, 120, 15, 10);
  }
  if (b31) {
    fill("green"); // certos
  rect(250, 450, 120, 15, 10) // certa
  
  }else if( b32 || b33 || b34){
    fill("red")
  rect(250, 480, 120, 15, 10)
  rect(250, 510, 120, 15, 10)
  rect(250, 540, 120, 15, 10)  
  } else {
    fill("blue"); // Normal
  }
  
  textSize(16)
  fill("white")
  text("Seul", 310, 460)

  textSize(16)
  fill("white")
  text("Busan", 310, 490)
    
  textSize(16)
  fill("white")
  text("Jeju", 310, 520)
    
  textSize(16)
  fill("white")
  text("Okinawa", 310, 550)
 // texto alternativas 3 
    
  } // segunda tela nivel fácil
  
  function telaFacil3(){

  image(eua, 50, 50, 100, 100)
  image(frança, 50,250, 100, 100)
  image(italia, 50, 450, 100, 100)

  fill("black")
  text("Estados Unidos",100,170)
  text("França",100,370)
  text("Itália",100,570)
  text("Nível fácil",310, 30)

  fill("blue")
  rect(450, 80, 110, 30, 10)
  fill("white")
  text("Fases", 500, 95) // botão retornar fases
    
  for (var i = 0; i < 4; i++) {
    fill("blue");
    rect(250, 50 + i * 30, 120, 15, 10);
  }
    
  if (b13) {
    fill("green"); // certos
  rect(250, 110, 120, 15, 10) // certa

  }else if( b11 || b12 || b14){
    fill("red")
  rect(250, 50, 120, 15, 10) 
  rect(250, 80, 120, 15, 10)
  rect(250, 140, 120, 15, 10)
  } else {
    fill("blue"); // Normal
  }
    
  textSize(16)
  fill("white")
  text("Orlando", 310, 60)

    
  textSize(16)
  fill("white")
  text("Nova York", 310, 90)
    
  textSize(16)
  fill("white")
  text("Washington", 310, 120)
    
  textSize(16)
  fill("white")
  text("Las Vegas", 310, 150)
 // texto alternativas 1
    
  for (var i = 0; i < 4; i++) {
    fill("blue");
    rect(250, 250+ i * 30, 120, 15, 10);
  }
  // botões alternativas 2
  if (b24) {
    fill("green"); // certos
  rect(250, 340, 120, 15, 10) // certa

  }else if( b21 || b22 || b23){
    fill("red")
  rect(250, 250, 120, 15, 10)
  rect(250, 280, 120, 15, 10) 
  rect(250, 310, 120, 15, 10)
  } else {
    fill("blue"); // Normal
  }
  
  textSize(16)
  fill("white")
  text("Nice", 310, 260)

    
  textSize(16)
  fill("white")
  text("Lyon", 310, 290)
    
  textSize(16)
  fill("white")
  text("Mônaco", 310, 320)
    
  textSize(16)
  fill("white")
  text("Paris", 310, 350)
 // texto alternativas 2
    
  for (var i = 0; i < 4; i++) {
    fill("blue");
    rect(250,450 + i * 30, 120, 15, 10);
  } 
  // botões alternativas 3
  if (b31) {
    fill("green"); // certos
  rect(250, 450, 120, 15, 10) // certa

  }else if( b32|| b33 || b34){
    fill("red")
  rect(250, 480, 120, 15, 10)
  rect(250, 510, 120, 15, 10)
  rect(250, 540, 120, 15, 10)
  } else {
    fill("blue"); // Normal
  }
  
  textSize(16)
  fill("white")
  text("Roma", 310, 460)

  textSize(16)
  fill("white")
  text("Milão", 310, 490)
    
  textSize(16)
  fill("white")
  text("Veneza", 310, 520)
    
  textSize(16)
  fill("white")
  text("Nápoles", 310, 550)
 // texto alternativas 3 
    
  fill("black")
  text("PONTUAÇÃO",500,270)
  text(pontosfacil,500,300)
} // terceira tela nivel facil
   
  function telaNivelmedio(){

  image(mexico, 50, 50, 100, 100)
  image(reinounido, 50,250, 100, 100)
  image(china, 50, 450, 100, 100)
    
  fill("black")
  text("México",100,170)
  text("Reino Unido",100,370)
  text("China",100,570)
  text("Nível médio",310, 30)

  fill("blue")
  rect(450, 20, 110, 30, 10)
  fill("white")
  text("Próximo", 500, 35) // botão próxima tela
    
  for (var i = 0; i < 4; i++) {
    fill("blue");
    rect(250, 50 + i * 30, 120, 15, 10);
  }
  // botões alternativas 1
  if (b11) {
    fill("green"); // certos
  rect(250, 50, 120, 15, 10) // certa

  }else if( b12|| b13 || b14){
    fill("red")
  rect(250, 80, 120, 15, 10)
  rect(250, 110, 120, 15, 10) 
  rect(250, 140, 120, 15, 10)
  } else {
    fill("blue"); // Normal
  }
    
  textSize(16)
  fill("white")
  text("Cidade do México", 310, 60)

    
  textSize(16)
  fill("white")
  text("Cancún", 310, 90)
    
  textSize(16)
  fill("white")
  text("Tijuana", 310, 120)
    
  textSize(16)
  fill("white")
  text("Puebla", 310, 150)
 // texto alternativas 1
    
  for (var i = 0; i < 4; i++) {
    fill("blue");
    rect(250, 250 + i * 30, 120, 15, 10);
  }
  // botões alternativas 2
  if (b24) {
    fill("green"); // certos
  rect(250, 340, 120, 15, 10) // certa

  }else if( b22|| b23 || b23){
    fill("red")
  rect(250, 250, 120, 15, 10)
  rect(250, 280, 120, 15, 10) 
  rect(250, 310, 120, 15, 10)
  } else {
    fill("blue"); // Normal
  }
  textSize(16)
  fill("white")
  text("Brighton", 310, 260)

    
  textSize(16)
  fill("white")
  text("Liverpool", 310, 290)
    
  textSize(16)
  fill("white")
  text("Manchester", 310, 320)
    
  textSize(16)
  fill("white")
  text("Londres", 310, 350)
 // texto alternativas 2
    
  for (var i = 0; i < 4; i++) {
    fill("blue");
    rect(250, 450 + i * 30, 120, 15, 10);
  }
  // botões alternativas 3
  if (b31) {
    fill("green"); // certos
  rect(250, 450, 120, 15, 10) // certa

  }else if( b32|| b33 || b34){
    fill("red")
  rect(250, 480, 120, 15, 10)
  rect(250, 510, 120, 15, 10)
  rect(250, 540, 120, 15, 10) 
  } else {
    fill("blue"); // Normal
  }
  
  textSize(16)
  fill("white")
  text("Pequim", 310, 460)

  textSize(16)
  fill("white")
  text("Hong Kong", 310, 490)
    
  textSize(16)
  fill("white")
  text("Wuhan", 310, 520)
    
  textSize(16)
  fill("white")
  text("Xangai", 310, 550)
 // texto alternativas 3 
  }
  
  function telaMedio2(){

  image(israel, 50, 50, 100, 100)
  image(grecia, 50,250, 100, 100)
  image(catar, 50, 450, 100, 100)

  fill("black")
  text("Israel",100,170)
  text("Grécia",100,370)
  text("Catar",100,570)
  text("Nível médio",310, 30)

  fill("blue")
  rect(450, 20, 110, 30, 10)
  fill("white")
  text("Próximo", 500, 35) // botão próxima tela
    
  for (var i = 0; i < 4; i++) {
    fill("blue");
    rect(250, 50 + i * 30, 120, 15, 10);
  }
  // botões alternativas 1
  if (b12) {
    fill("green"); // certos
  rect(250, 80, 120, 15, 10) // certa

  }else if( b11|| b13 || b14){
    fill("red")
  rect(250, 110, 120, 15, 10) 
  rect(250, 140, 120, 15, 10)
  rect(250, 50, 120, 15, 10) 
  } else {
    fill("blue"); // Normal
  }
    
  textSize(16)
  fill("white")
  text("Palestina", 310, 60)

    
  textSize(16)
  fill("white")
  text("Jerusalem", 310, 90)
    
  textSize(16)
  fill("white")
  text("Berseba", 310, 120)
    
  textSize(16)
  fill("white")
  text("Tel aviv", 310, 150)
 // texto alternativas 1
    
  for (var i = 0; i < 4; i++) {
    fill("blue");
    rect(250, 250 + i * 30, 120, 15, 10);
  }
  // botões alternativas 2
  if (b24) {
    fill("green"); // certos
  rect(250, 340, 120, 15, 10) // certa

  }else if( b21|| b22 || b23){
    fill("red")
  rect(250, 250, 120, 15, 10)
  rect(250, 280, 120, 15, 10) 
  rect(250, 310, 120, 15, 10)
  } else {
    fill("blue"); // Normal
  }
  
  textSize(16)
  fill("white")
  text("Zeus", 310, 260)

    
  textSize(16)
  fill("white")
  text("Janina", 310, 290)
    
  textSize(16)
  fill("white")
  text("Alexandrópolis", 310, 320)
    
  textSize(16)
  fill("white")
  text("Atenas", 310, 350)
 // texto alternativas 2
    
  for (var i = 0; i < 4; i++) {
    fill("blue");
    rect(250, 450 + i * 30, 120, 15, 10);
  }
  // botões alternativas 3
  if (b33){
    fill("green"); // certos
  rect(250, 510, 120, 15, 10) // certa
    
  }else if (b31|| b32 || b34){
    fill("red")
  rect(250, 450, 120, 15, 10) 
  rect(250, 480, 120, 15, 10)
  rect(250, 540, 120, 15, 10) 
  } else {
    fill("blue"); // Normal
  }
  textSize(16)
  fill("white")
  text("Al Hilal", 310, 460)

  textSize(16)
  fill("white")
  text("Teerã", 310, 490)
    
  textSize(16)
  fill("white")
  text("Doha", 310, 520)
    
  textSize(16)
  fill("white")
  text("Abu Dhabi", 310, 550)
 // texto alternativas 3 
    
  } // segunda tela nivel medio
  
  function telaMedio3(){

  image(australia, 50, 50, 100, 100)
  image(suiça, 50,250, 100, 100)
  image(cuba, 50, 450, 100, 100)

  fill("black")
  text("Austrália",100,170)
  text("Suiça",100,370)
  text("Cuba",100,570)
  text("Nível médio",310, 30)

  fill("blue")
  rect(450, 80, 110, 30, 10)
  fill("white")
  text("Fases", 500, 95) // botão retornar fases
    
  for (var i = 0; i < 4; i++) {
    fill("blue");
    rect(250, 50 + i * 30, 120, 15, 10);
  }
  // botões alternativas 1
  if (b13){
    fill("green"); // certos
  rect(250, 110, 120, 15, 10) // certa
    
  }else if (b11|| b12 || b14){
    fill("red")
  rect(250, 50, 120, 15, 10) 
  rect(250, 80, 120, 15, 10) 
  rect(250, 140, 120, 15, 10)
  } else {
    fill("blue"); // Normal
  }    
  textSize(16)
  fill("white")
  text("Melbourne", 310, 60)

    
  textSize(16)
  fill("white")
  text("Sydney", 310, 90)
    
  textSize(16)
  fill("white")
  text("Canberra", 310, 120)
    
  textSize(16)
  fill("white")
  text("Brisbane", 310, 150)
 // texto alternativas 1
    
  for (var i = 0; i < 4; i++) {
    fill("blue");
    rect(250,250+ i * 30, 120, 15, 10);
  }
  // botões alternativas 2
  if (b21){
    fill("green"); // certos
    rect(250, 250, 120, 15, 10) // certa

  }else if (b22|| b23 || b24){
    fill("red")
  rect(250, 280, 120, 15, 10) 
  rect(250, 310, 120, 15, 10)
  rect(250, 340, 120, 15, 10) 
  } else {
    fill("blue"); // Normal
  } 
  textSize(16)
  fill("white")
  text("Berna", 310, 260)

    
  textSize(16)
  fill("white")
  text("Zurique", 310, 290)
    
  textSize(16)
  fill("white")
  text("Genebra", 310, 320)
    
  textSize(16)
  fill("white")
  text("Lugano", 310, 350)
 // texto alternativas 2
    
  for (var i = 0; i < 4; i++) {
    fill("blue");
    rect(250, 450 + i * 30, 120, 15, 10);
  }
  // botões alternativas 3
    if (b34){
    fill("green"); // certos
  rect(250, 540, 120, 15, 10) // certa

  }else if (b31|| b33 || b32){
    fill("red")
  rect(250, 450, 120, 15, 10) 
  rect(250, 480, 120, 15, 10)
  rect(250, 510, 120, 15, 10) 
  } else {
    fill("blue"); // Normal
  } 
  
  textSize(16)
  fill("white")
  text("Trinidad", 310, 460)

  textSize(16)
  fill("white")
  text("Bayamo", 310, 490)
    
  textSize(16)
  fill("white")
  text("Santa Clara", 310, 520)
    
  textSize(16)
  fill("white")
  text("Havana", 310, 550)
 // texto alternativas 3 
  
  fill("black")
  text("PONTUAÇÃO",500,270)
  text(pontosmedio,500,300)
  } // terceira tela nivel medio

  function telaNiveldificil(){

  image(nepal, 50, 50, 100, 100)
  image(libano, 50,250, 100, 100)
  image(irlanda, 50, 450, 100, 100)

  fill("black")
  text("Nepal",100,170)
  text("Líbano",100,370)
  text("Irlanda",100,570)
  text("Nível difícil",310, 30)

  fill("blue")
  rect(450, 20, 110, 30, 10)
  fill("white")
  text("Próximo", 500, 35) // botão próxima tela
    
  for (var i = 0; i < 4; i++) {
    fill("blue");
    rect(250, 50 + i * 30, 120, 15, 10);
  }
  // botões alternativas 1
    if (b12){
    fill("green"); // certos
  rect(250, 80, 120, 15, 10) // certa

  }else if (b11|| b12 || b14){
    fill("red")
  rect(250, 110, 120, 15, 10) 
  rect(250, 140, 120, 15, 10)
  rect(250, 50, 120, 15, 10) 
  } else {
    fill("blue"); // Normal
  } 
    
  textSize(16)
  fill("white")
  text("Patan", 310, 60)

    
  textSize(16)
  fill("white")
  text("Katmandu", 310, 90)
    
  textSize(16)
  fill("white")
  text("Pokhara", 310, 120)
    
  textSize(16)
  fill("white")
  text("Everest", 310, 150)
 // texto alternativas 1
    
  for (var i = 0; i < 4; i++) {
    fill("blue");
    rect(250, 250 + i * 30, 120, 15, 10);
  }
  // botões alternativas 2
    if (b24){
    fill("green"); // certos
  rect(250, 340, 120, 15, 10) // certa

  }else if (b21|| b22 || b23){
    fill("red")
  rect(250, 250, 120, 15, 10)
  rect(250, 280, 120, 15, 10) 
  rect(250, 310, 120, 15, 10)
  } else {
    fill("blue"); // Normal
  } 
  
  textSize(16)
  fill("white")
  text("Batroun", 310, 260)

    
  textSize(16)
  fill("white")
  text("Tiro", 310, 290)
    
  textSize(16)
  fill("white")
  text("Sídon", 310, 320)
    
  textSize(16)
  fill("white")
  text("Beirute", 310, 350)
 // texto alternativas 2
    
  for (var i = 0; i < 4; i++) {
    fill("blue");
    rect(250, 450 + i * 30, 120, 15, 10);
  }
  // botões alternativas 3
    if (b31){
    fill("green"); // certos
  rect(250, 450, 120, 15, 10)  // certa

  }else if (b32|| b33 || b34){
    fill("red")
  rect(250, 480, 120, 15, 10)
  rect(250, 510, 120, 15, 10) 
  rect(250, 540, 120, 15, 10) 
  } else {
    fill("blue"); // Normal
  } 
  
  textSize(16)
  fill("white")
  text("Dublin", 310, 460)

  textSize(16)
  fill("white")
  text("Watford", 310, 490)
    
  textSize(16)
  fill("white")
  text("Galway", 310, 520)
    
  textSize(16)
  fill("white")
  text("Bray", 310, 550)
 // texto alternativas 3 
 }
  
  function telaDificil2(){

  image(albania, 50, 50, 100, 100)
  image(vietna, 50,250, 100, 100)
  image(nicaragua, 50, 450, 100, 100)
    
  fill("black")
  text("Albânia",100,170)
  text("Vietnã",100,370)
  text("Nicarágua",100,570)
  text("Nível difícil",310, 30)

  fill("blue")
  rect(450, 20, 110, 30, 10)
  fill("white")
  text("Próximo", 500, 35) // botão próxima tela
    
    fill("blue")
  rect(450, 20, 110, 30, 10)
  fill("white")
  text("Próximo", 500, 35) // botão próxima tela
    
  for (var i = 0; i < 4; i++) {
    fill("blue");
    rect(250, 50 + i * 30, 120, 15, 10);
  }
  // botões alternativas 1
  if (b12){
    fill("green"); // certos
  rect(250, 80, 120, 15, 10) // certa

  }else if (b11|| b13 || b14){
    fill("red")
  rect(250, 110, 120, 15, 10) 
  rect(250, 140, 120, 15, 10)
  rect(250, 50, 120, 15, 10) 
  
  } else {
    fill("blue"); // Normal
  } 
    
  textSize(16)
  fill("white")
  text("Vilinus", 310, 60)

    
  textSize(16)
  fill("white")
  text("Tirana", 310, 90)
    
  textSize(16)
  fill("white")
  text("Talin", 310, 120)
    
  textSize(16)
  fill("white")
  text("Varsóvia", 310, 150)
 // texto alternativas 1
    
  for (var i = 0; i < 4; i++) {
    fill("blue");
    rect(250, 250 + i * 30, 120, 15, 10);
  }
  // botões alternativas 2
    if (b21){
    fill("green"); // certos
  rect(250, 250, 120, 15, 10) // certa

  }else if (b22|| b23 || b24){
    fill("red")
  rect(250, 280, 120, 15, 10) 
  rect(250, 310, 120, 15, 10)
  rect(250, 340, 120, 15, 10) 
  
  } else {
    fill("blue"); // Normal
  } 
  
  textSize(16)
  fill("white")
  text("Hanói", 310, 260)

    
  textSize(16)
  fill("white")
  text("Camboja", 310, 290)
    
  textSize(16)
  fill("white")
  text("Bangkok", 310, 320)
    
  textSize(16)
  fill("white")
  text("Kanto", 310, 350)
 // texto alternativas 2
    
  for (var i = 0; i < 4; i++) {
    fill("blue");
    rect(250, 450 + i * 30, 120, 15, 10);
  }
  // botões alternativas 3
    if (b34){
    fill("green"); // certos
  rect(250, 540, 120, 15, 10) // certa

  }else if (b31|| b32 || b33){
    fill("red")
  rect(250, 450, 120, 15, 10) 
  rect(250, 480, 120, 15, 10)
  rect(250, 510, 120, 15, 10) 
  
  } else {
    fill("blue"); // Normal
  } 
  textSize(16)
  fill("white")
  text("León", 310, 460)

  textSize(16)
  fill("white")
  text("San José", 310, 490)
    
  textSize(16)
  fill("white")
  text("Tegucigalpa", 310, 520)
    
  textSize(16)
  fill("white")
  text("Manágua", 310, 550)
 // texto alternativas 3     
  }
  
  function telaDificil3(){

  image(macedoniadonorte, 50, 50, 100, 100)
  image(escocia, 50,250, 100, 100)
  image(dinamarca, 50, 450, 100, 100)
    
  fill("black")
  text("Macedônia do Norte",100,170)
  text("Escócia",100,370)
  text("Dinamarca",100,570)
  text("Nível difícil",310, 30)

    fill("blue")
  rect(450, 80, 110, 30, 10)
  fill("white")
  text("Fases", 500, 95) // botão retornar fases
    
  for (var i = 0; i < 4; i++) {
    fill("blue");
    rect(250, 50 + i * 30, 120, 15, 10);
  }
  // botões alternativas 1
    
    if (b12){
    fill("green"); // certos
  rect(250, 80, 120, 15, 10) // certa

  }else if (b11|| b13 || b14){
    fill("red")
  rect(250, 110, 120, 15, 10) 
  rect(250, 140, 120, 15, 10)
  rect(250, 50, 120, 15, 10) 
  
  } else {
    fill("blue"); // Normal
  } 
    
  textSize(16)
  fill("white")
  text("Palestina", 310, 60)

    
  textSize(16)
  fill("white")
  text("Bitola", 310, 90)
    
  textSize(16)
  fill("white")
  text("Kosovo", 310, 120)
    
  textSize(16)
  fill("white")
  text("Telavive", 310, 150)
 // texto alternativas 1
    
  for (var i = 0; i < 4; i++) {
    fill("blue");
    rect(250, 250 + i * 30, 120, 15, 10);
  }
  // botões alternativas 2
    if (b21){
  fill("green"); // certos
  rect(250, 250, 120, 15, 10)

  }else if (b22|| b23 || b24){
    fill("red")
  rect(250, 280, 120, 15, 10) 
  rect(250, 310, 120, 15, 10)
  rect(250, 340, 120, 15, 10) // certa

  } else {
    fill("blue"); // Normal
  } 
  textSize(16)
  fill("white")
  text("Edimburgo", 310, 260)

    
  textSize(16)
  fill("white")
  text("Dundee", 310, 290)
    
  textSize(16)
  fill("white")
  text("Estocolmo", 310, 320)
    
  textSize(16)
  fill("white")
  text("Kiruna", 310, 350)
 // texto alternativas 2
    
  for (var i = 0; i < 4; i++) {
    fill("blue");
    rect(250, 450 + i * 30, 120, 15, 10);
  }
  // botões alternativas 3
    if (b32){
  fill("green"); // certos
  rect(250, 480, 120, 15, 10)

  }else if (b31|| b33 || b34){
    fill("red")
  rect(250, 450, 120, 15, 10) 
  rect(250, 540, 120, 15, 10) 
  rect(250, 510, 120, 15, 10) // certa

  } else {
    fill("blue"); // Normal
  } 
  
  textSize(16)
  fill("white")
  text("Helsinque", 310, 460)

  textSize(16)
  fill("white")
  text("Copenhague ", 310, 490)
    
  textSize(16)
  fill("white")
  text("Oslo", 310, 520)
    
  textSize(16)
  fill("white")
  text("Viena", 310, 550)
 // texto alternativas 3   
    
  fill("black")
  text("PONTUAÇÃO",500,270)
  text(pontosdificil,500,300)
  }